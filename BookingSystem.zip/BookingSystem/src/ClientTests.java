public class ClientTests {
    public static void main(String[] args) {
        // rooms for the hotel
        int[] rooms = {121, 122, 123, 124, 125, 126};
        // instantiate hotel
        Hotel hotel = new Hotel(
            rooms
        );

        // Create multiple threads
        Thread client1 = new Thread(() -> {
            hotel.bookRoom("REF1", new int[]{0, 1}, 121);
            hotel.roomBooked(new int[]{0, 1}, 121);

            // Testing multiple rooms at once
            hotel.bookRooms("REF10", new int[]{11,12,15}, new int[]{123,124});
        });

        Thread client2 = new Thread(() -> {
            hotel.bookRoom("REF2", new int[]{1, 2}, 122);
            try{
                hotel.updateBooking("REF2", new int[]{5, 6}, 122);
            }
            catch(NoSuchBookingException nsbe){
                System.out.println("Booking Does Not Exist.");
            }
            // multiple room checks
            hotel.roomsBooked(new int[]{13,14,15}, new int[]{123}); // - room 123 is booked for day 15
        });

        // Start the client threads
        client1.start();
        client2.start();

        // Wait for all client threads to finish
        try
        {
            client1.join();
            client2.join();
        } catch (InterruptedException e)
        {
            System.out.println("Interrupted thread");
        }
    }
}