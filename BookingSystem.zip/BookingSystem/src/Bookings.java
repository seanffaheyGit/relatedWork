import java.util.concurrent.ConcurrentHashMap;

public class Bookings
{
    public ConcurrentHashMap<Integer, String> bookings; // links days booked to booking references

    Bookings(){
        bookings = new ConcurrentHashMap<>();
    }
}
