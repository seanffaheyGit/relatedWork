// Hotel Class - for booking rooms in the hotel

import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

public class Hotel {
    private ConcurrentHashMap<Integer, Bookings> roomBookings; // links roomNumbers to Bookings (Booking References with Days Booked)
    private Semaphore s = new Semaphore(1); // binary semaphore - for concurrency, one single resource

    public Hotel(int[] roomNums){
        // create blank list of bookings
        roomBookings = new ConcurrentHashMap<>();
        for(int roomNumber : roomNums)
        {
            roomBookings.put(roomNumber, new Bookings()); // place blank bookings in each room number
        }
    }

    // return true if roomNum is booked on any day in days
    public boolean roomBooked(int[] days, int roomNum){
        try
        {
                // acquire semaphore
                s.acquire();
                // ensure room number exists
                if (!RoomExists(roomNum))
                {
                    // the room number does not exist - return false
                    System.out.println("Room " + roomNum + " does not exist!");
                    return false;
                }

                // check if the room is booked
                for(int day : days)
                {
                    // does the room number have the associated day in "days"? if so, the room is booked
                    if(roomBookings.get(roomNum).bookings.containsKey(day))
                    {
                        System.out.println("Room " + roomNum + " is booked.");
                        return true;
                    }
                }
                // return false - no matching bookings have been found
                return false;
        }
        // handle Interrupted Thread exception from semaphore
        catch(InterruptedException ie){
            Thread.currentThread().interrupt();
            return false;
        }
        finally{
            // release semaphore
            s.release();
        }
    }

    // return true if possible to book all rooms, false if not
    public boolean bookRoom(String bookingRef, int[] days, int roomNum){
        try{
            // ensure the specified room exists
            if(!RoomExists(roomNum)){
                System.out.println("Room " + roomNum + " does not exist!");
                return false;
            }

            // check if any room has been booked already - return false if so
            if(roomBooked(days, roomNum))
            {
                System.out.println("Room already booked.");
                return false;
            }
            else{
                // get the semaphore
                s.acquire();
                for(int day : days){
                    // book the room for the days
                    roomBookings.get(roomNum).bookings.put(day, bookingRef);
                }
                System.out.println("Room " + roomNum + " booked successfully.");
                return true;
            }
        }
        catch(InterruptedException ie)
        {
            Thread.currentThread().interrupt();
            return false;
        }
        finally{
            // release semaphore
            s.release();
        }
    }

    // update 'bookingRef' so it refers to roomNum for each day in days
    public boolean updateBooking(String bookingRef, int[] days, int roomNum) throws NoSuchBookingException
    {
          try
          {
              // cancel the booking
              cancelBooking(bookingRef);
              // book the room - returing the same return value as bookRoom function
              return bookRoom(bookingRef, days, roomNum);
          }
          catch(NoSuchBookingException nsbe)
          {
              throw new NoSuchBookingException(bookingRef);
          }
    }

    // cancel bookings under 'bookingRef'
    public void cancelBooking(String bookingRef) throws NoSuchBookingException
    {
        try
        {
            // acquire semaphore
            s.acquire();

            // true if booking is found
            boolean bookingFound = false;
            // loop through bookings to find the specified reference ID
            for (ConcurrentHashMap.Entry<Integer, Bookings> entry : roomBookings.entrySet())
            {
                Bookings bookings = entry.getValue();
                // check if the booking reference exists
                for (int day : bookings.bookings.keySet())
                {
                    if (bookings.bookings.get(day).equals(bookingRef)) {
                        bookings.bookings.remove(day);
                        bookingFound = true;
                    }
                }
            }

            // if not found - booking never existed
            if(!bookingFound)
            {
                throw new NoSuchBookingException(bookingRef);
            }
        }
        catch(InterruptedException ie){
            Thread.currentThread().interrupt();
        }
        finally {
            // release the semaphore
            s.release();
        }
    }

    // method to check the room number exists
    private boolean RoomExists(int roomNum){
        return roomBookings.containsKey(roomNum);
    }

    // Handling multiple rooms
    // - multiple rooms booked?
    public boolean roomsBooked(int[] days, int[] roomNums)
    {
        // ensure room numbers exist
        for(int roomNum : roomNums)
        {
            if (!RoomExists(roomNum))
            {
                // the room number does not exist - return false
                System.out.println("Room " + roomNum + " does not exist!");
                return false;
            }
        }
        // check if any of the rooms are booked
        for(int roomNum : roomNums)
        {
            if(roomBooked(days, roomNum))
            {
                return true;
            }
        }
        // return false if no matches found
        return false;
    }

    // returns true if all booking is successful
    public boolean bookRooms(String bookingRef, int[] days, int roomNums[]) {
        try {
            // ensure the specified rooms exist
            for (int roomNum : roomNums) {
                if (!RoomExists(roomNum)) {
                    // the room number does not exist - return false
                    System.out.println("Room " + roomNum + " does not exist!");
                    return false;
                }
            }
            // check if any room has been booked already - return false if so
            if (roomsBooked(days, roomNums)) {
                System.out.println("One of these rooms are already booked.");
                return false;
            } else {
                // get the semaphore
                s.acquire();
                // book the rooms
                for (int roomNum : roomNums) {
                    for (int day : days) {
                        // book the room for the days
                        roomBookings.get(roomNum).bookings.put(day, bookingRef);
                    }
                    System.out.println("Room " + roomNum + " booked successfully.");
                    return true;
                }
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            return false;
        } finally {
            // release semaphore
            s.release();
        }
        return false;
    }

    // update bookings for multiple rooms
    public boolean updateBookings(String bookingRef, int[] days, int[] roomNums) throws NoSuchBookingException
    {
        // cancel all current days booked under this reference
        cancelBooking(bookingRef);
        // book new days
        return bookRooms(bookingRef, days, roomNums);
    }
}